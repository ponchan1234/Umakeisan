﻿namespace UmamusumeKeisanTool
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonKeisan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelOut = new System.Windows.Forms.Label();
            this.checkBoxpace = new System.Windows.Forms.CheckBox();
            this.labelAnn = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxInput
            // 
            this.textBoxInput.Location = new System.Drawing.Point(75, 163);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(100, 19);
            this.textBoxInput.TabIndex = 0;
            // 
            // buttonReset
            // 
            this.buttonReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonReset.Location = new System.Drawing.Point(84, 224);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 23);
            this.buttonReset.TabIndex = 2;
            this.buttonReset.Text = "リセット";
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonKeisan
            // 
            this.buttonKeisan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.buttonKeisan.Location = new System.Drawing.Point(44, 312);
            this.buttonKeisan.Name = "buttonKeisan";
            this.buttonKeisan.Size = new System.Drawing.Size(164, 66);
            this.buttonKeisan.TabIndex = 1;
            this.buttonKeisan.Text = "計算する";
            this.buttonKeisan.UseVisualStyleBackColor = false;
            this.buttonKeisan.Click += new System.EventHandler(this.buttonKeisan_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(181, 166);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.label1.Size = new System.Drawing.Size(17, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "個";
            // 
            // labelOut
            // 
            this.labelOut.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold);
            this.labelOut.Location = new System.Drawing.Point(14, 275);
            this.labelOut.Name = "labelOut";
            this.labelOut.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.labelOut.Size = new System.Drawing.Size(210, 34);
            this.labelOut.TabIndex = 4;
            this.labelOut.Text = "label2";
            // 
            // checkBoxpace
            // 
            this.checkBoxpace.AutoSize = true;
            this.checkBoxpace.Font = new System.Drawing.Font("MS UI Gothic", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBoxpace.Location = new System.Drawing.Point(13, 253);
            this.checkBoxpace.Name = "checkBoxpace";
            this.checkBoxpace.Size = new System.Drawing.Size(211, 19);
            this.checkBoxpace.TabIndex = 3;
            this.checkBoxpace.Text = "交換可能なピースを計算する";
            this.checkBoxpace.UseVisualStyleBackColor = true;
            this.checkBoxpace.CheckedChanged += new System.EventHandler(this.checkBoxpace_CheckedChanged);
            // 
            // labelAnn
            // 
            this.labelAnn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAnn.AutoSize = true;
            this.labelAnn.BackColor = System.Drawing.SystemColors.Control;
            this.labelAnn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelAnn.Location = new System.Drawing.Point(11, 186);
            this.labelAnn.Name = "labelAnn";
            this.labelAnn.Padding = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.labelAnn.Size = new System.Drawing.Size(35, 16);
            this.labelAnn.TabIndex = 6;
            this.labelAnn.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(243, 436);
            this.Controls.Add(this.labelAnn);
            this.Controls.Add(this.checkBoxpace);
            this.Controls.Add(this.labelOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonKeisan);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.textBoxInput);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "ウマ娘計算機";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonKeisan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelOut;
        private System.Windows.Forms.CheckBox checkBoxpace;
        private System.Windows.Forms.Label labelAnn;
    }
}

