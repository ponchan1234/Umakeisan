﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace UmamusumeKeisanTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;
        }

        //変数宣言
        int megami = 0;
        int pace = 0;
        int i = 0;
        bool InPutflg;
        bool Sizeflg;
        bool flg;
        bool numflg;

        private void Form1_Load(object sender, EventArgs e)
        {
            reset();
            //背景色を透明に変更
            labelOut.BackColor = Color.Transparent;
            checkBoxpace_CheckedChanged(sender,e);
        }
        private void buttonReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void buttonKeisan_Click(object sender, EventArgs e)
        {
            //変数初期化
            megami = 0;
            i = 0;
            pace = 0;

            //背景色を白に変更
            labelOut.BackColor = SystemColors.Control;



            if (checkBoxpace.CheckState == CheckState.Checked)
            {

                InputCheck();
                if (!InPutflg == false)
                    NumCheck();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
                if (!numflg == false)
                    SizeCheck();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
                if (!Sizeflg == false)
                    Exchange();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
            }
            else
            {
                InputCheck();
                if (!InPutflg == false)
                    NumCheck();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
                if (!numflg == false)
                    SizeCheck();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
                if (!Sizeflg == false)
                    Necessary();
                else
                {
                    labelOut.BackColor = Color.Transparent;
                    return;
                }
            }
        }

        //入力チェック
        private void InputCheck()
        {
            if (string.IsNullOrEmpty(textBoxInput.Text))
            {
                MessageBox.Show("数字を入力してください。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Text = "";
                textBoxInput.Focus();
                InPutflg = false;
            }
            else
                InPutflg = true;
        }

        //数字が入力されたかチェック
        private void NumCheck()
        {
            Regex regex = new Regex(@"^[0-9]+$");

            if (!regex.IsMatch(textBoxInput.Text))
            {
                MessageBox.Show("半角数字を入力してください", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error).ToString();
                textBoxInput.Text = "";
                textBoxInput.Focus();
                numflg = false;
            }
            else
                numflg = true;
        }

        //入力された数字の桁数チェック
        private void SizeCheck()
        {
            if (textBoxInput.TextLength > 3 && checkBoxpace.CheckState == CheckState.Unchecked)
            {
                MessageBox.Show("三桁以内で入力してください。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Text = "";
                textBoxInput.Focus();
                Sizeflg = false;
                return;
            }
            else
                Sizeflg = true;

            if (checkBoxpace.CheckState == CheckState.Unchecked)
                flg = int.TryParse(textBoxInput.Text, out pace);
            if (checkBoxpace.CheckState == CheckState.Checked)
                flg = int.TryParse(textBoxInput.Text, out megami);

            if (pace > 650 || megami > 3000)
            {
                MessageBox.Show("女神像交換は650回まで可能です。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxInput.Text = "";
                textBoxInput.Focus();
                Sizeflg = false;
            }
            else
                Sizeflg = true;
        }


        //入力をリセット
        private void reset()
        {
            labelOut.BackColor = Color.Transparent;
            megami = 0;
            pace = 0;
            i = 0;
            textBoxInput.Text = "";
            labelOut.Text = "";
            textBoxInput.Focus();
        }

        //女神像必要数計算
        private void Necessary()
        {
            for (i = 1; i <= pace; i++)
            {
                if (i < 26)
                    megami = megami + 1;
                else
                    break;
            }

            for (i = 26; i <= pace; i++)
            {
                if (i < 51)
                    megami = megami + 2;
                else
                    break;
            }

            for (i = 51; i <= pace; i++)
            {
                if (i < 76)
                    megami = megami + 3;
                else
                    break;
            }

            for (i = 76; i <= pace; i++)
            {
                if (i < 101)
                    megami = megami + 4;
                else
                    break;
            }

            for (i = 101; i <= pace; i++)
            {
                if (i < 651)
                    megami = megami + 5;
                else
                    break;
            }

            labelOut.Text = "交換に必要な女神像の個数は" + megami + "個です。";
        }

        //交換可能なピースの数の計算
        private void Exchange()
        {
            for (i = 1; i <= megami; i++)
            {
                if (i < 26)
                    pace = pace + 1;
                else
                    break;
            }

            for (i = 26; i < megami; i = i + 2)
            {
                if (i < 76)
                    pace = pace + 1;
                else
                    break;
            }

            for (i = 76; i < megami; i = i + 3)
            {
                if (i < 151)
                    pace = pace + 1;
                else
                    break;
            }

            for (i = 151; i < megami; i = i + 4)
            {
                if (i < 251)
                    pace = pace + 1;
                else
                    break;
            }

            for (i = 251; i < megami; i = i + 5)
            {
                if (i < 3001 || i <= megami)
                    pace = pace + 1;
                else
                    break;
            }

            labelOut.Text = "交換可能なピースは" + pace + "個です";
        }

        private void checkBoxpace_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxpace.CheckState == CheckState.Unchecked)
                labelAnn.Text = "ほしいピースの数を入力してください";
            else
                labelAnn.Text = "所持している女神像の数を入力してください";
        }
    }
}
